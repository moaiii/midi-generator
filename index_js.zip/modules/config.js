module.exports = {
  "accessKeyId": "AKIAJZXR7PQV6PXYNVGA", 
  "secretAccessKey": "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", 
  "region": "us-east-1" 
};